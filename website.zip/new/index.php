<?php include'header.php'?>


<div class="row">

<div class="col-sm-8">

<strong><span style="font-size:3em; line-height:1.8; color:white">
Welcome to Lun Wing Design<br/>
&#35; Ying Lun<br/>
&#35; Freelancer<br/>
&#35; Web Desgin<br/>
&#35; Graphic Desgin<br/>
&#35; Brisbane,QLD<br/>
&#35; Logan,QLD<br/></span></strong>

</div>
<div class="col-sm-4">
<strong><span style="font-size:3em; line-height:1.8; color:white">
&#35; Photography<br/></span></strong>
<img src="img/DSC_0795_1.jpg" width="312" height="64"/><br/>
<img src="img/DSC_0801_1.jpg" width="312" height="64"/><br/>
<img src="img/DSC_0803_1.jpg" width="312" height="64"/><br/>
<img src="img/DSC_1143_1.jpg" width="312" height="64"/><br/>

</div>
</div><!--end row-->


</div>


<div class="col-sm-3">


</div>
<div class="col-sm-3">


</div>
<div class="col-sm-3">


</div>
</div>

	    
 <?php include'footer.php'?>

        