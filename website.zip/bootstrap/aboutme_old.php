<?php include'header.php'?>



<div class="row">
<div class="col-sm-4">
<strong><span style="color:#54284e; font-size:1.3em">What I do?<br/></span></strong><br/>
<strong><span style="color:#77bc1f">Print Design:<br/></span></strong>
<li>Logo Design</li>
<li> Business Stationary</li>
<li>Flyers & Brochures</li>
<li>Posters</li>
<li>Calendars</li>
<li>Book & E-book Covers</li>
<li>CD & DVD Covers</li>
<li>Invitations & Postcards</li>
<li>Presentation Material</li>
</div>


<div class="col-sm-4">
<br/><br/>
<strong><span style="color:#77bc1f">Web Design:<br/></span></strong>
<li>Business Websites</li>
<li>Portfolio Sites</li>
<li>Personal websites</li>
<li>Personal or Business Blogs</li>
<li>CMS Websites</li>
<li>WordPress Implementation</li>
</div>


<div class="col-sm-4">
<strong><span style="color:#54284e; font-size:1.3em">My Skills<br/></span></strong><br/>

<img src="img/logos.png" width="100%">


<div id="cvbottoncontainer">
<div id="cvbotton"><a href="mailto:contactme@lunwing.com" target="_blank">
Requst for My Rusume
</a>
</div>
</div>
</div>


</div>





        <?php include'footer.php'?>

       