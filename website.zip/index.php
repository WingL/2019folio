<?php include'header.php'?>

<div class="col-sm-10 col-sm-offset-1">
<img src="img/SAM_0476.jpg" width="100%">
<img src="img/DSC_0792.jpg" width="100%">
<img src="img/DSC_0803.jpg" width="100%">
<img src="img/DSC_0801.jpg" width="100%">
</div>





	    
 <?php include'footer.php'?>

        