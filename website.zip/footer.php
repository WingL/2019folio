</div><!--end outerWrapper div (starts at the header.php file)-->

<div id="footer_container" class="container">
<footer>
<div id="copyright">Copyright &copy; Ying Lun</div>
<div id="date"><?php echo date('Y'); echo " "?></div>
</footer>
</div>

</body>
</html>